import React from 'react';
import ReactDOM from 'react-dom';
import Grafica from './components/grafica';

ReactDOM.render(<Grafica/>, document.getElementById('root'));
